#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class KMPLActionsKmp, KMPLKotlinUnit, KMPLPaddingKmp, KMPLRuntimeCompositionLocal<T>, KMPLRuntimeProvidableCompositionLocal<T>, KMPLRuntimeProvidedValue<T>, KMPLSelectorsKMP, UIViewController;

@protocol KMPLRuntimeCompositionLocalAccessorScope;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface KMPLBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface KMPLBase (KMPLBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface KMPLMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface KMPLMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorKMPLKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface KMPLNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface KMPLByte : KMPLNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface KMPLUByte : KMPLNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface KMPLShort : KMPLNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface KMPLUShort : KMPLNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface KMPLInt : KMPLNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface KMPLUInt : KMPLNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface KMPLLong : KMPLNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface KMPLULong : KMPLNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface KMPLFloat : KMPLNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface KMPLDouble : KMPLNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface KMPLBoolean : KMPLNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ActionsKmp")))
@interface KMPLActionsKmp : KMPLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)actionsKmp __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KMPLActionsKmp *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ACTION_TEXT __attribute__((swift_name("ACTION_TEXT")));
@property (readonly) int32_t CURRENT_INDEX __attribute__((swift_name("CURRENT_INDEX")));
@property (readonly) float ROW_CIRCLE_VISIBILITY __attribute__((swift_name("ROW_CIRCLE_VISIBILITY")));
@property (readonly) NSString *ROW_TEXT __attribute__((swift_name("ROW_TEXT")));
@property (readonly) int32_t SLIDER_TOTAL_DOTS __attribute__((swift_name("SLIDER_TOTAL_DOTS")));
@property (readonly) int32_t TOTAL_DOTS __attribute__((swift_name("TOTAL_DOTS")));
@property (readonly) uint64_t actionTextColor __attribute__((swift_name("actionTextColor")));
@property (readonly) uint64_t arrowColor __attribute__((swift_name("arrowColor")));
@property (readonly) uint64_t backgroundRollColor __attribute__((swift_name("backgroundRollColor")));
@property (readonly) uint64_t foreColor __attribute__((swift_name("foreColor")));
@property (readonly) void (^onClick)(void) __attribute__((swift_name("onClick")));
@property (readonly) uint64_t rowCircleColor __attribute__((swift_name("rowCircleColor")));
@property (readonly) uint64_t rowIconColor __attribute__((swift_name("rowIconColor")));
@property (readonly) uint64_t rowTextColor __attribute__((swift_name("rowTextColor")));
@property (readonly) uint64_t selectedColor __attribute__((swift_name("selectedColor")));
@property (readonly) uint64_t socialRowCircleColor __attribute__((swift_name("socialRowCircleColor")));
@property (readonly) uint64_t socialRowIconColor __attribute__((swift_name("socialRowIconColor")));
@property (readonly) uint64_t unselectedColor __attribute__((swift_name("unselectedColor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PaddingKmp")))
@interface KMPLPaddingKmp : KMPLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)paddingKmp __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KMPLPaddingKmp *shared __attribute__((swift_name("shared")));
@property (readonly) float PADDING_VISIBILITY __attribute__((swift_name("PADDING_VISIBILITY")));
@property (readonly) uint64_t paddingBackgroundColor __attribute__((swift_name("paddingBackgroundColor")));
@property (readonly) float paddingHeight __attribute__((swift_name("paddingHeight")));
@property (readonly) float paddingWidth __attribute__((swift_name("paddingWidth")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SelectorsKMP")))
@interface KMPLSelectorsKMP : KMPLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)selectorsKMP __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KMPLSelectorsKMP *shared __attribute__((swift_name("shared")));
@property (readonly) float selector __attribute__((swift_name("selector")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DefaultsValKt")))
@interface KMPLDefaultsValKt : KMPLBase
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<NSString *> *DefaultActionText __attribute__((swift_name("DefaultActionText")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultActionTextColor __attribute__((swift_name("DefaultActionTextColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultArrowColor __attribute__((swift_name("DefaultArrowColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultBackgroundRollColor __attribute__((swift_name("DefaultBackgroundRollColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLInt *> *DefaultCurrentIndex __attribute__((swift_name("DefaultCurrentIndex")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultForeColor __attribute__((swift_name("DefaultForeColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLKotlinUnit *(^)(void)> *DefaultOnClick __attribute__((swift_name("DefaultOnClick")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultPaddingBackgroundColor __attribute__((swift_name("DefaultPaddingBackgroundColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultPaddingHeight __attribute__((swift_name("DefaultPaddingHeight")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLFloat *> *DefaultPaddingVisibility __attribute__((swift_name("DefaultPaddingVisibility")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultPaddingWidth __attribute__((swift_name("DefaultPaddingWidth")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultRowCircleColor __attribute__((swift_name("DefaultRowCircleColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLFloat *> *DefaultRowCircleVisibility __attribute__((swift_name("DefaultRowCircleVisibility")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultRowIconColor __attribute__((swift_name("DefaultRowIconColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<NSString *> *DefaultRowText __attribute__((swift_name("DefaultRowText")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultRowTextColor __attribute__((swift_name("DefaultRowTextColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultSelectedColor __attribute__((swift_name("DefaultSelectedColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultSelector __attribute__((swift_name("DefaultSelector")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLInt *> *DefaultSliderTotalDots __attribute__((swift_name("DefaultSliderTotalDots")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultSocialRowCircleColor __attribute__((swift_name("DefaultSocialRowCircleColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultSocialRowIconColor __attribute__((swift_name("DefaultSocialRowIconColor")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<KMPLInt *> *DefaultTotalDots __attribute__((swift_name("DefaultTotalDots")));
@property (class, readonly) KMPLRuntimeProvidableCompositionLocal<id> *DefaultUnselectedColor __attribute__((swift_name("DefaultUnselectedColor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FunctionsComposeIosKt")))
@interface KMPLFunctionsComposeIosKt : KMPLBase
+ (float)toDp:(float)receiver __attribute__((swift_name("toDp(_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FunctionsForIosKt")))
@interface KMPLFunctionsForIosKt : KMPLBase
+ (UIViewController *)dotBannerViewControllerTotalDots:(int32_t)totalDots currentIndex:(int32_t)currentIndex unselectedColorHex:(NSString *)unselectedColorHex selectedColorHex:(NSString *)selectedColorHex __attribute__((swift_name("dotBannerViewController(totalDots:currentIndex:unselectedColorHex:selectedColorHex:)")));
+ (UIViewController *)dotPersonalOfferViewControllerTotalDots:(int32_t)totalDots unselectedColorHex:(NSString *)unselectedColorHex selectedColorHex:(NSString *)selectedColorHex __attribute__((swift_name("dotPersonalOfferViewController(totalDots:unselectedColorHex:selectedColorHex:)")));
+ (uint64_t)parseColorHexHex:(NSString *)hex __attribute__((swift_name("parseColorHex(hex:)")));
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
__attribute__((swift_name("RuntimeCompositionLocal")))
@interface KMPLRuntimeCompositionLocal<T> : KMPLBase
@end


/**
 * @note annotations
 *   androidx.compose.runtime.Stable
*/
__attribute__((swift_name("RuntimeProvidableCompositionLocal")))
@interface KMPLRuntimeProvidableCompositionLocal<T> : KMPLRuntimeCompositionLocal<T>
- (KMPLRuntimeProvidedValue<T> *)providesValue:(T _Nullable)value __attribute__((swift_name("provides(value:)")));
- (KMPLRuntimeProvidedValue<T> *)providesComputedCompute:(T _Nullable (^)(id<KMPLRuntimeCompositionLocalAccessorScope>))compute __attribute__((swift_name("providesComputed(compute:)")));
- (KMPLRuntimeProvidedValue<T> *)providesDefaultValue:(T _Nullable)value __attribute__((swift_name("providesDefault(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface KMPLKotlinUnit : KMPLBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) KMPLKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeProvidedValue")))
@interface KMPLRuntimeProvidedValue<T> : KMPLBase
@property (readonly) BOOL canOverride __attribute__((swift_name("canOverride")));
@property (readonly) KMPLRuntimeCompositionLocal<T> *compositionLocal __attribute__((swift_name("compositionLocal")));
@property (readonly) T _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("RuntimeCompositionLocalAccessorScope")))
@protocol KMPLRuntimeCompositionLocalAccessorScope
@required
- (id _Nullable)currentValue:(KMPLRuntimeCompositionLocal<id> *)receiver __attribute__((swift_name("currentValue(_:)")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
